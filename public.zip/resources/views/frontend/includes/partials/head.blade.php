<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="IT Solution, Sass and Multipurpose HTML Template">
<meta name="keywords" content="IT Solution, Sass and Multipurpose HTML Template">
<meta name="robots" content="INDEX,FOLLOW">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Title -->
<title> Zalgo Infotech - IT Solution</title>
<!-- Favicon -->
<link rel="shortcut icon" href="{{asset('assets/images/logo/favicon.png')}}">
<!-- Bootstrap -->
<link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
<!-- aos -->
<link rel="stylesheet" href="{{asset('assets/css/aos.css')}}">
<!-- Swiper -->
<link rel="stylesheet" href="{{asset('assets/css/swiper-bundle.min.css')}}">
<!-- Magnific -->
<link rel="stylesheet" href="{{asset('assets/css/magnific-popup.css')}}">
<!-- Satoshi -->
<link rel="stylesheet" href="{{asset('assets/css/satoshi.css')}}">
<!-- Main css -->
<link rel="stylesheet" href="{{asset('assets/css/main.css')}}">
