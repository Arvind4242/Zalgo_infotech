@extends('frontend.layouts.app')
@section('title', 'Index Two')
@section('content')

    <!-- header area -->
    @include('frontend.includes.headers.headerOne')
    <!-- header area end -->
    
        <div id="smooth-content">
            <!-- Banner Two Start -->
            <section class="banner-two position-relative z-1 gradient-bg-two">
                <img src="{{asset('assets/images/shapes/cloud-shape.png')}}" alt="Cloud Shape"
                    class="position-absolute bottom-0 tw-start-0 w-100 z-n1" />

                <div class="banner-two__inner position-relative">
                    <div class="container">
                        <div class="row gy-4">
                            <div class="col-lg-6">
                                <div class="banner-two-content">
                                    <div class="bg-white-06 tw-py-3 tw-px-305 tw-rounded text-white fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="600">
                                        <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                                        Up to <span class="text-yellow">70%</span> off managed
                                        cloud hosting
                                    </div>
                                    <h1 class="splitTextStyleOne text-white text-capitalize tw-leading-none">
                                        Organized cloud &
                                        <span class="text-yellow font-dm-serif fst-italic fw-normal">web hosting</span>
                                        for your business
                                    </h1>
                                    <p class="splitTextStyleOne text-neutral-300 tw-mt-8 max-w-388-px fw-medium">
                                        Touch the success! Domain and Secure Web Hosting from
                                        <span class="text-yellow">$4.99</span> per month
                                    </p>

                                    <div class="d-flex align-items-center tw-gap-7 tw-mt-11 flex-wrap" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                        <a href="{{route('register')}}"
                                            class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-15 rounded-pill tw-py-505 fw-medium"
                                            data-block="button">
                                            <span class="button__flair"></span>
                                            <span class="button__label">Clients Area</span>
                                        </a>
                                        <p class="text-neutral-300 max-w-388-px fw-medium" data-aos="fade-up"
                                            data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                            Starting at only
                                            <span class="text-yellow">$3.27/mo*</span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="banner-two-thumb">
                                    <img src="{{asset('assets/images/thumbs/banner-two-img.png')}}" alt="Image" data-aos="zoom-in"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="1000" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Banner Two End -->

            <!-- Search Domain Start -->
            <section class="search-domain position-relative z-1 tw--mt-170-px" data-aos="fade-up"
                data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                <img src="{{asset('assets/images/shapes/hand-thumb.png')}}" alt="Hand thumb"
                    class="hand-thumb left-right-animation position-absolute tw-start-0 top-0 tw-mt-15" />

                <div class="container">
                    <div class="bg-white common-shadow-six tw-pt-10 tw-pb-16 tw-px-88-px">
                        <h3 class="text-center tw-mb-4 text-capitalize splitTextStyleOne">
                            Search and buy a
                            <span class="text-yellow font-dm-serif fst-italic fw-normal">domain</span>
                            in minutes
                        </h3>
                        <div class="text-center" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                            data-aos-duration="800">
                            <ul class="animate-background-wrapper z-1 position-relative nav nav-pills active-text-white d-inline-flex border border-neutral-200 rounded-pill tw-mb-6"
                                id="pills-tab" role="tablist">
                                <li class="background"></li>

                                <li class="nav-item flex-grow-1" role="presentation">
                                    <button
                                        class="nav-link w-100 active-scale-094 rounded-pill tw-px-6 tw-py-305 bg-transparent fw-semibold text-heading hover-text-main-600 h-100 line-clamp-1 active"
                                        id="pills-FindNewDomain-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-FindNewDomain" type="button" role="tab"
                                        aria-controls="pills-FindNewDomain" aria-selected="true">
                                        Find New Domain
                                    </button>
                                </li>
                                <li class="nav-item flex-grow-1" role="presentation">
                                    <button
                                        class="nav-link w-100 active-scale-094 rounded-pill tw-px-6 tw-py-305 bg-transparent fw-semibold text-heading hover-text-main-600 h-100 line-clamp-1"
                                        id="pills-GeneratedomainusingAI-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-GeneratedomainusingAI" type="button" role="tab"
                                        aria-controls="pills-GeneratedomainusingAI" aria-selected="false">
                                        Generate domain using AI
                                    </button>
                                </li>
                            </ul>
                        </div>

                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-FindNewDomain" role="tabpanel"
                                aria-labelledby="pills-FindNewDomain-tab" tabindex="0">
                                <div class="select-domain-wrapper">
                                    <form action="#" class="d-flex tw-gap-6 flex-column flex-sm-row"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="600">
                                        <div class="position-relative flex-grow-1">
                                            <input type="text"
                                                class="tw-py-405 tw-px-705 tw-pe-100-px bg-neutral-100 tw-rounded-xl border-transparent placeholder-neutral-600 placeholder-18-px w-100"
                                                placeholder="Enter your desire domain name" />
                                            <select
                                                class="select-domain form-control form-select w-auto border-0 tw-py-1 tw-pe-305 shadow-none form-select-arrow-end position-absolute tw-end-0 top-50 translate-middle-y bg-transparent tw-me-705 fw-semibold">
                                                <option value=".com">.com</option>
                                                <option value=".cloud">.cloud</option>
                                                <option value=".shop">.shop</option>
                                                <option value=".online">.online</option>
                                                <option value=".info">.info</option>
                                            </select>
                                        </div>
                                        <button type="button"
                                            class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-15 tw-py-505 fw-semibold"
                                            data-block="button">
                                            <span class="button__flair"></span>
                                            <span class="button__label">Search</span>
                                        </button>
                                    </form>
                                    <div class="overflow-x-max-lg-auto scroll-sm scroll-sm-horizontal pb-sm-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="600">
                                        <div class="tw-mt-6 d-grid grid-col-5 min-w-max tw-pb-1">
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end border-start"
                                                data-domain=".com">
                                                <img src="{{asset('assets/images/thumbs/domain-img1.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".cloud">
                                                <img src="{{asset('assets/images/thumbs/domain-img2.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$14.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".shop">
                                                <img src="{{asset('assets/images/thumbs/domain-img3.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".online">
                                                <img src="{{asset('assets/images/thumbs/domain-img4.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".info">
                                                <img src="{{asset('assets/images/thumbs/domain-img5.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                        </div>
                                    </div>

                                    <div class="text-center text-heading fw-medium tw-mt-8" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                        Already bought a domain?
                                        <a href="javascript:void(0)"
                                            class="fw-bold text-decoration-underline text-heading hover-text-main-600">Transfer
                                            it?</a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-GeneratedomainusingAI" role="tabpanel"
                                aria-labelledby="pills-GeneratedomainusingAI-tab" tabindex="0">
                                <div class="select-domain-wrapper">
                                    <form action="#" class="d-flex tw-gap-6 flex-column flex-sm-row"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="600">
                                        <div class="position-relative flex-grow-1">
                                            <input type="text"
                                                class="tw-py-405 tw-px-705 tw-pe-100-px bg-neutral-100 tw-rounded-xl border-transparent placeholder-neutral-600 placeholder-18-px w-100"
                                                placeholder="Enter your desire domain name" required />
                                            <select
                                                class="select-domain form-control form-select w-auto border-0 tw-py-1 tw-pe-305 shadow-none form-select-arrow-end position-absolute tw-end-0 top-50 translate-middle-y bg-transparent tw-me-705 fw-semibold">
                                                <option value=".com">.com</option>
                                                <option value=".cloud">.cloud</option>
                                                <option value=".shop">.shop</option>
                                                <option value=".online">.online</option>
                                                <option value=".info">.info</option>
                                            </select>
                                        </div>
                                        <button type="submit"
                                            class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-15 tw-py-505 fw-semibold"
                                            data-block="button">
                                            <span class="button__flair"></span>
                                            <span class="button__label">Search</span>
                                        </button>
                                    </form>
                                    <div class="overflow-x-max-lg-auto scroll-sm scroll-sm-horizontal pb-sm-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="600">
                                        <div class="tw-mt-6 d-grid grid-col-5 min-w-max tw-pb-1">
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end border-start"
                                                data-domain=".com">
                                                <img src="{{asset('assets/images/thumbs/domain-img1.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".cloud">
                                                <img src="{{asset('assets/images/thumbs/domain-img2.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$14.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".shop">
                                                <img src="{{asset('assets/images/thumbs/domain-img3.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".online">
                                                <img src="{{asset('assets/images/thumbs/domain-img4.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                            <button type="button"
                                                class="domain-item-button text-center tw-py-205 tw-px-5 border-bottom hover-common-shadow-four animation-item border-top border-neutral-200 border-end"
                                                data-domain=".info">
                                                <img src="{{asset('assets/images/thumbs/domain-img5.png')}}" alt="Domain Logo"
                                                    class="animate__wobble" />
                                                <span class="d-block text-neutral-600 tw-mt-105 tw-mb-1">Starting
                                                    price</span>
                                                <span
                                                    class="d-block text-neutral-700 tw-mt-1 tw-text-sm fw-semibold">$13.34/Yearly</span>
                                            </button>
                                        </div>
                                    </div>

                                    <div class="text-center text-heading fw-medium tw-mt-8" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                        Already bought a domain?
                                        <a href="javascript:void(0)"
                                            class="fw-bold text-decoration-underline text-heading hover-text-main-600">Transfer
                                            it?</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="text-center tw-mt-11 text-heading fw-medium d-flex align-items-center tw-gap-4 justify-content-center flex-wrap"
                        data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                        <span class="">Our Customers say <span class="fw-bold tw-ms-2">Great</span>
                        </span>
                        <img src="{{asset('assets/images/icons/ratings.svg')}}" alt="img" class="" />
                        <span class="">4.1 out of 5 based on 16,158 reviews</span>
                        <div class="d-flex align-items-center tw-gap-05">
                            <img src="{{asset('assets/images/icons/trustpilot-star.svg')}}" alt="img" />
                            <span class="fw-bold">Trustpilot</span>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Search Domain End -->

            <!-- About Two Section start -->
            <section class="about-two py-120 position-relative z-1 overflow-hidden">
                <img src="{{asset('assets/images/shapes/squre-box-shape.png')}}" alt="Square shape"
                    class="position-absolute top-50 tw-start-0 tw-ms-128-px animate__wobble__two z-n1 d-lg-block d-none" />

                <div class="container">
                    <div class="row gy-4 flex-wrap-reverse">
                        <!-- About two thumbs slider start -->
                        <div class="col-lg-5">
                            <div class="tw-rounded-lg background-img tw-px-7 bg-img position-relative max-w-570-px"
                                data-background-image="{{asset('assets/images/thumbs/about-two-img-bg.png')}}">
                                <img src="{{asset('assets/images/shapes/finger-shape.png')}}" alt="Shape"
                                    class="flower animate__wobble__two position-absolute tw-end-100 bottom-100 tw--m-24-px z-n1" />

                                <div class="d-flex tw-gap-6 tw-max-h-588-px">
                                    <!-- First Slider start -->
                                    <div class="swiper overflow-hidden about-two-thumbs-slider-one w-50">
                                        <div class="swiper-wrapper transition-timing-linear tw-gap-6">
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img1.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img2.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img3.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img1.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img2.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img3.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img1.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img2.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img3.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- First Slider end -->

                                    <!-- Second Slider start -->
                                    <div class="swiper overflow-hidden about-two-thumbs-slider-two w-50">
                                        <div class="swiper-wrapper transition-timing-linear tw-gap-6">
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img1.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img2.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img3.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img1.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img2.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img3.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img1.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img2.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="tw-rounded-2xl overflow-hidden">
                                                    <img src="{{asset('assets/images/thumbs/about-slide-img3.png')}}" alt="Image"
                                                        class="w-100 h-100 object-fit-cover" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Second Slider end -->
                                </div>
                            </div>
                        </div>
                        <!-- About two thumbs slider End -->

                        <!-- About two content start -->
                        <div class="col-lg-7 ps-lg-5">
                            <div class="">
                                <div class="bg-neutral-100 tw-py-3 tw-px-305 rounded-pill text-heading fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                                    data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                    <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                                    Up to <span class="text-yellow">70%</span> off managed cloud
                                    hosting
                                </div>
                                <h2 class="splitTextStyleOne text-heading text-capitalize">
                                    Sasstech makes you a better
                                    <span class="font-dm-serif fst-italic fw-normal">elevating</span>
                                    your team's
                                </h2>
                                <p class="splitTextStyleOne text-neutral-500 tw-mt-8 max-w-570-px fw-medium tw-text-lg">
                                    In today's competitive business, the demand for efficient In
                                    today's competitive cost-effective IT solutions has never
                                    been more critic. business
                                </p>

                                <div class="tw-mt-8">
                                    <div class="d-flex align-items-center tw-gap-16">
                                        <div class="d-flex flex-column tw-gap-305">
                                            <div class="d-flex align-items-center tw-gap-405 animation-item"
                                                data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                                data-aos-duration="600">
                                                <span
                                                    class="tw-w-11 tw-h-10 text-heading bg-neutral-200 tw-rounded-md d-flex justify-content-center align-items-center tw-text-xl">
                                                    <i class="animate__heartBeat ph-bold ph-magnifying-glass"></i>
                                                </span>
                                                <a href="{{route('pricing')}}"
                                                    class="fw-bold tw-text-lg text-heading hover-underline">Domain</a>
                                            </div>
                                            <div class="d-flex align-items-center tw-gap-405 animation-item"
                                                data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                                data-aos-duration="600">
                                                <span
                                                    class="tw-w-11 tw-h-10 text-heading bg-neutral-200 tw-rounded-md d-flex justify-content-center align-items-center tw-text-xl">
                                                    <i class="animate__heartBeat ph-bold ph-dresser"></i>
                                                </span>
                                                <a href="{{route('pricing')}}"
                                                    class="fw-bold tw-text-lg text-heading hover-underline">Web Hosting ₹
                                                    79.00/mo</a>
                                            </div>
                                            <div class="d-flex align-items-center tw-gap-405 animation-item"
                                                data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                                data-aos-duration="600">
                                                <span
                                                    class="tw-w-11 tw-h-10 text-heading bg-neutral-200 tw-rounded-md d-flex justify-content-center align-items-center tw-text-xl">
                                                    <i class="animate__heartBeat ph-bold ph-certificate"></i>
                                                </span>
                                                <a href="{{route('pricing')}}"
                                                    class="fw-bold tw-text-lg text-heading hover-underline">SSL
                                                    Certificates</a>
                                            </div>
                                            <div class="d-flex align-items-center tw-gap-405 animation-item"
                                                data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                                data-aos-duration="600">
                                                <span
                                                    class="tw-w-11 tw-h-10 text-heading bg-neutral-200 tw-rounded-md d-flex justify-content-center align-items-center tw-text-xl">
                                                    <i class="animate__heartBeat ph-bold ph-envelope"></i>
                                                </span>
                                                <a href="{{route('pricing')}}"
                                                    class="fw-bold tw-text-lg text-heading hover-underline">Professional
                                                    Email</a>
                                            </div>
                                        </div>
                                        <div
                                            class="d-flex align-items-center tw-gap-9 tw-ms-705 d-sm-flex d-none flex-shrink-0">
                                            <span class="tw-h-114-px tw-w-1-px bg-neutral-200"></span>
                                            <span class="fw-bold tw-text-lg text-heading text-uppercase">OR</span>
                                        </div>
                                        <div class="tw-ms-205 left-right-animation d-sm-flex d-none">
                                            <img src="{{asset('assets/images/shapes/curve-arrow-two.png')}}" alt="img" />
                                        </div>
                                    </div>
                                </div>
                                <div class="tw-mt-8 max-w-500-px" data-aos="fade-up"
                                    data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                    <a href="{{route('pricing')}}"
                                        class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-lg-flex d-none align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-15 tw-rounded-md tw-py-505 fw-medium"
                                        data-block="button">
                                        <span class="button__flair"></span>
                                        <span class="button__label">See Plan & Pricing</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- About two content end -->
                    </div>
                </div>
            </section>
            <!-- About Two Section end -->

            <!-- Hosting plan section start -->
            <section class="hosting-plan tw-pt-224-px pb-120 position-relative z-1 overflow-hidden">
                <img src="{{asset('assets/images/shapes/wave-shape.png')}}" alt="Shape"
                    class="position-absolute w-100 h-100 top-0 tw-start-0 z-n1" />
                <img src="{{asset('assets/images/shapes/dots-circle-round.png')}}" alt="Shape"
                    class="position-absolute bottom-0 tw-start-0 tw-ms-80-px scale-animation d-lg-block d-none" />

                <div class="container">
                    <div class="d-flex align-items-center justify-content-between tw-gap-6 tw-mb-12">
                        <div class="max-w-724-px">
                            <div class="bg-neutral-200 tw-py-3 tw-px-305 rounded-pill text-heading fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                                data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                                Up to <span class="text-yellow">70%</span> off managed cloud
                                hosting
                            </div>
                            <h2 class="splitTextStyleOne text-heading text-capitalize">
                                Pick your perfect
                                <span class="font-dm-serif fst-italic fw-normal">
                                    web hosting
                                </span>
                                plan. We got'em all.
                            </h2>
                        </div>
                        <div class="" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                            data-aos-duration="800">
                            <a href="{{route('register')}}"
                                class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-lg-flex d-none align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-15 rounded-pill tw-py-505 fw-medium"
                                data-block="button">
                                <span class="button__flair"></span>
                                <span class="button__label">Clients Area</span>
                            </a>
                        </div>
                    </div>

                    <div class="position-relative">
                        <div class="bg-white common-shadow-seven tw-rounded-2xl overflow-hidden">
                            <div class="hosting-plan-slider swiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide h-100" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                        <div
                                            class="group hosting-plan-item tw-ps-48-px tw-pe-4 tw-pt-90-px tw-pb-9 hover-bg-main-600 h-100 d-flex flex-column justify-content-between animation-item tw-duration-300">
                                            <div class="">
                                                <span class="">
                                                    <img src="{{asset('assets/images/icons/hosting-plan-icon1.png')}}" alt="Icon"
                                                        class="animate__swing" />
                                                </span>
                                                <div class="tw-mt-10">
                                                    <span class="tw-mb-3 d-block text-heading">
                                                        <span class="tw-duration-200 group-hover-text-white">Starts at
                                                        </span>
                                                        <span
                                                            class="text-purple tw-duration-200 group-hover-text-yellow fw-bold">$3.75/mo*</span>
                                                    </span>
                                                    <h5 class="tw-mb-3 tw-duration-200 group-hover-text-white">
                                                        Web hosting
                                                    </h5>
                                                    <p
                                                        class="text-neutral-500 tw-text-base line-clamp-2 tw-duration-200 group-hover-text-white">
                                                        Easy, affordable, and includes a free domain for a
                                                        year. Score!
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="tw-mt-705">
                                                <a href="javascript:void(0)"
                                                    class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-inline-flex align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-705 tw-py-305 fw-medium tw-rounded-md text-sm group-hover-bg-white tw-duration-400 group-hover-text-main-two-600 hosting-plan-btn"
                                                    data-block="button">
                                                    <span class="button__flair"></span>
                                                    <span class="button__label">Learn more</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide h-100" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="700">
                                        <div
                                            class="group hosting-plan-item tw-ps-48-px tw-pe-4 tw-pt-90-px tw-pb-9 hover-bg-main-600 h-100 d-flex flex-column justify-content-between animation-item tw-duration-300">
                                            <div class="">
                                                <span class="">
                                                    <img src="{{asset('assets/images/icons/hosting-plan-icon2.png')}}" alt="Icon"
                                                        class="animate__swing" />
                                                </span>
                                                <div class="tw-mt-10">
                                                    <span class="tw-mb-3 d-block text-heading">
                                                        <span class="tw-duration-200 group-hover-text-white">Starts at
                                                        </span>
                                                        <span
                                                            class="text-purple tw-duration-200 group-hover-text-yellow fw-bold">$3.75/mo*</span>
                                                    </span>
                                                    <h5 class="tw-mb-3 tw-duration-200 group-hover-text-white">
                                                        WordPress hosting
                                                    </h5>
                                                    <p
                                                        class="text-neutral-500 tw-text-base line-clamp-2 tw-duration-200 group-hover-text-white">
                                                        Easy, affordable, and includes a free domain for a
                                                        year. Score!
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="tw-mt-705">
                                                <a href="javascript:void(0)"
                                                    class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-inline-flex align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-705 tw-py-305 fw-medium tw-rounded-md text-sm group-hover-bg-white tw-duration-400 group-hover-text-main-two-600 hosting-plan-btn"
                                                    data-block="button">
                                                    <span class="button__flair"></span>
                                                    <span class="button__label">Learn more</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide h-100" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                        <div
                                            class="group hosting-plan-item tw-ps-48-px tw-pe-4 tw-pt-90-px tw-pb-9 hover-bg-main-600 h-100 d-flex flex-column justify-content-between animation-item tw-duration-300">
                                            <div class="">
                                                <span class="">
                                                    <img src="{{asset('assets/images/icons/hosting-plan-icon3.png')}}" alt="Icon"
                                                        class="animate__swing" />
                                                </span>
                                                <div class="tw-mt-10">
                                                    <span class="tw-mb-3 d-block text-heading">
                                                        <span class="tw-duration-200 group-hover-text-white">Starts at
                                                        </span>
                                                        <span
                                                            class="text-purple tw-duration-200 group-hover-text-yellow fw-bold">$3.75/mo*</span>
                                                    </span>
                                                    <h5 class="tw-mb-3 tw-duration-200 group-hover-text-white">
                                                        VPS hosting
                                                    </h5>
                                                    <p
                                                        class="text-neutral-500 tw-text-base line-clamp-2 tw-duration-200 group-hover-text-white">
                                                        Easy, affordable, and includes a free domain for a
                                                        year. Score!
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="tw-mt-705">
                                                <a href="javascript:void(0)"
                                                    class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-inline-flex align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-705 tw-py-305 fw-medium tw-rounded-md text-sm group-hover-bg-white tw-duration-400 group-hover-text-main-two-600 hosting-plan-btn"
                                                    data-block="button">
                                                    <span class="button__flair"></span>
                                                    <span class="button__label">Learn more</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide h-100" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="900">
                                        <div
                                            class="group hosting-plan-item tw-ps-48-px tw-pe-4 tw-pt-90-px tw-pb-9 hover-bg-main-600 h-100 d-flex flex-column justify-content-between animation-item tw-duration-300">
                                            <div class="">
                                                <span class="">
                                                    <img src="{{asset('assets/images/icons/hosting-plan-icon4.png')}}" alt="Icon"
                                                        class="animate__swing" />
                                                </span>
                                                <div class="tw-mt-10">
                                                    <span class="tw-mb-3 d-block text-heading">
                                                        <span class="tw-duration-200 group-hover-text-white">Starts at
                                                        </span>
                                                        <span
                                                            class="text-purple tw-duration-200 group-hover-text-yellow fw-bold">$3.75/mo*</span>
                                                    </span>
                                                    <h5 class="tw-mb-3 tw-duration-200 group-hover-text-white">
                                                        Dedicated hosting
                                                    </h5>
                                                    <p
                                                        class="text-neutral-500 tw-text-base line-clamp-2 tw-duration-200 group-hover-text-white">
                                                        Easy, affordable, and includes a free domain for a
                                                        year. Score!
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="tw-mt-705">
                                                <a href="javascript:void(0)"
                                                    class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-inline-flex align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-705 tw-py-305 fw-medium tw-rounded-md text-sm group-hover-bg-white tw-duration-400 group-hover-text-main-two-600 hosting-plan-btn"
                                                    data-block="button">
                                                    <span class="button__flair"></span>
                                                    <span class="button__label">Learn more</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide h-100" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="1000">
                                        <div
                                            class="group hosting-plan-item tw-ps-48-px tw-pe-4 tw-pt-90-px tw-pb-9 hover-bg-main-600 h-100 d-flex flex-column justify-content-between animation-item tw-duration-300">
                                            <div class="">
                                                <span class="">
                                                    <img src="{{asset('assets/images/icons/hosting-plan-icon2.png')}}" alt="Icon"
                                                        class="animate__swing" />
                                                </span>
                                                <div class="tw-mt-10">
                                                    <span class="tw-mb-3 d-block text-heading">
                                                        <span class="tw-duration-200 group-hover-text-white">Starts at
                                                        </span>
                                                        <span
                                                            class="text-purple tw-duration-200 group-hover-text-yellow fw-bold">$3.75/mo*</span>
                                                    </span>
                                                    <h5 class="tw-mb-3 tw-duration-200 group-hover-text-white">
                                                        WordPress hosting
                                                    </h5>
                                                    <p
                                                        class="text-neutral-500 tw-text-base line-clamp-2 tw-duration-200 group-hover-text-white">
                                                        Easy, affordable, and includes a free domain for a
                                                        year. Score!
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="tw-mt-705">
                                                <a href="javascript:void(0)"
                                                    class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-inline-flex align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-705 tw-py-305 fw-medium tw-rounded-md text-sm group-hover-bg-white tw-duration-400 group-hover-text-main-two-600 hosting-plan-btn"
                                                    data-block="button">
                                                    <span class="button__flair"></span>
                                                    <span class="button__label">Learn more</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div
                            class="swiper-hosting-button-next tw-w-14 tw-h-14 border border-neutral-200 rounded-circle text-main-600 tw-text-lg d-flex justify-content-center align-items-center hover-bg-main-600 hover-border-main-600 hover-text-white tw-transition tw-duration-200 position-absolute top-50 translate-middle-y tw-z-99 tw-start-100 tw-ms-705">
                            <i class="ph-bold ph-arrow-right"></i>
                        </div>
                        <div
                            class="swiper-hosting-button-prev tw-w-14 tw-h-14 border border-neutral-200 rounded-circle text-main-600 tw-text-lg d-flex justify-content-center align-items-center hover-bg-main-600 hover-border-main-600 hover-text-white tw-transition tw-duration-200 position-absolute top-50 translate-middle-y tw-z-99 tw-end-100 tw-me-705">
                            <i class="ph-bold ph-arrow-left"></i>
                        </div>

                        <div
                            class="swiper-hosting-pagination d-lg-none d-flex align-items-center justify-content-center tw-mt-605">
                        </div>
                    </div>
                </div>
            </section>
            <!-- Hosting plan section End -->

            <!-- degree view Section Start -->
            <section class="degree-view tw-pt-9">
                <div class="container">
                    <div class="max-w-672-px text-center mx-auto tw-mb-12">
                        <div class="bg-neutral-100 tw-py-3 tw-px-305 rounded-pill text-heading fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                            data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                            <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                            Up to <span class="text-yellow">70%</span> off managed cloud
                            hosting
                        </div>
                        <h2 class="splitTextStyleOne text-heading text-capitalize">
                            Get a 360-degree <br />
                            view of your
                            <span class="font-dm-serif fst-italic fw-normal">cloud</span>
                            spend
                        </h2>
                    </div>

                    <div class="row gy-4">
                        <div class="col-xl-8">
                            <div class="d-flex common-shadow-eight tw-rounded-3xl bg-white border border-neutral-100 flex-md-row flex-column"
                                data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                <div class="tw-rounded-3xl overflow-hidden flex-shrink-0">
                                    <img src="{{asset('assets/images/thumbs/degree-view-img1.png')}}" alt="Thumb"
                                        class="w-100 h-100 object-fit-cover" />
                                </div>
                                <div class="tw-py-13 tw-pe-8 flex-grow-1 tw-ps-11">
                                    <span
                                        class="tw-px-6 tw-py-1 bg-purple text-white rounded-pill fw-medium tw-mb-5">Hosting
                                        at should be</span>
                                    <h4 class="tw-mb-5">
                                        Web Hosting that's fast and reliable.
                                    </h4>
                                    <p class="text-neutral-500">
                                        Web hosting provides everything you need to get your idea
                                        online. From where your website lives in the digital
                                        world, to where your files and data are securely stored
                                        find and manage it all in one place.
                                    </p>
                                </div>
                            </div>
                            <div class="d-flex common-shadow-eight tw-rounded-3xl bg-white border border-neutral-100 flex-md-row flex-column tw-mt-8"
                                data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="700">
                                <div class="tw-rounded-3xl overflow-hidden flex-shrink-0">
                                    <img src="{{asset('assets/images/thumbs/degree-view-img2.png')}}" alt="Thumb"
                                        class="w-100 h-100 object-fit-cover" />
                                </div>
                                <div class="tw-py-13 tw-pe-8 flex-grow-1 tw-ps-11">
                                    <h4 class="tw-mb-5">
                                        <span class="text-purple">SSL</span> certificates help
                                        secure User's important data.
                                    </h4>
                                    <div class="d-flex align-items-center tw-gap-405 tw-mt-8">
                                        <span
                                            class="tw-w-11 tw-h-10 text-heading bg-neutral-200 tw-rounded-md d-flex justify-content-center align-items-center tw-text-xl">
                                            <i class="ph-bold ph-magnifying-glass"></i>
                                        </span>
                                        <a href="{{route('pricing')}}"
                                            class="fw-bold tw-text-lg text-heading hover-underline max-w-278-px">Helps your
                                            website search ranking with https</a>
                                    </div>
                                    <div class="tw-mt-8">
                                        <a href="{{route('pricing')}}"
                                            class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke d-inline-flex align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-705 tw-py-305 fw-medium tw-rounded-md text-sm group-hover-bg-white group-hover-text-main-two-600 hosting-plan-btn"
                                            data-block="button">
                                            <span class="button__flair"></span>
                                            <span class="button__label">Get Started</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                            data-aos-duration="800">
                            <div
                                class="d-flex common-shadow-eight tw-rounded-3xl bg-white border border-neutral-100 flex-column h-100">
                                <div class="tw-rounded-3xl overflow-hidden flex-shrink-0">
                                    <img src="{{asset('assets/images/thumbs/degree-view-img3.png')}}" alt="Thumb"
                                        class="w-100 h-100 object-fit-cover" />
                                </div>
                                <div class="tw-py-13 tw-pe-8 flex-grow-1 tw-ps-12">
                                    <h4 class="tw-mb-5">Give your website a good name</h4>
                                    <p class="text-neutral-500">
                                        Web hosting provides everything you need to idea online.
                                        From where your website lives in the world, to where your
                                        files and data are securely find and manage it all in one
                                        place.
                                    </p>
                                    <a href="{{route('pricing')}}"
                                        class="fw-bold tw-text-lg text-heading text-decoration-underline tw-mt-11 hover-text-main-600">Pick
                                        your Domain Today</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- degree view Section End -->

            <!-- Search Domain Two Start -->
            <section class="search-domain-two pt-120 tw-pb-10 position-relative z-1">
                <div class="max-w-1524-px mx-auto tw-pt-5">
                    <img src="{{asset('assets/images/shapes/border-square.png')}}" alt="Borders"
                        class="position-absolute tw-start-0 top-0 w-100 h-100 z-n1" />

                    <div class="container">
                        <div class="row gy-5">
                            <div class="col-sm-6">
                                <div class="max-w-444-px mx-auto text-center">
                                    <div class="common-shadow-eight tw-py-7 tw-px-705 tw-rounded-xl overflow-hidden">
                                        <img src="{{asset('assets/images/thumbs/search-domain-img2.png')}}" alt="Thumb"
                                            class="w-100 h-100 object-fit-cover" />
                                    </div>
                                    <div class="tw-mt-605">
                                        <h5 class="tw-mb-6 line-clamp-2">
                                            Launching a website is easier with AI
                                        </h5>
                                        <a href="{{route('register')}}"
                                            class="fw-bold tw-text-lg text-decoration-underline text-main-600 hover-text-yellow">Build
                                            your website today</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="max-w-444-px mx-auto text-center">
                                    <div class="common-shadow-eight tw-py-7 tw-px-705 tw-rounded-xl overflow-hidden">
                                        <img src="{{asset('assets/images/thumbs/search-domain-img1.png')}}" alt="Thumb"
                                            class="w-100 h-100 object-fit-cover" />
                                    </div>
                                    <div class="tw-mt-605">
                                        <h5 class="tw-mb-6 line-clamp-2">
                                            Transfer your Domain Today
                                        </h5>
                                        <a href="{{route('register')}}"
                                            class="fw-bold tw-text-lg text-decoration-underline text-main-600 hover-text-yellow">Transfer
                                            domain</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container">
                        <div class="pt-120">
                            <div class="row gy-4 select-domain-wrapper">
                                <div class="col-md-5">
                                    <div class="d-flex tw-gap-305 flex-wrap">
                                        <button type="button"
                                            class="domain-item-button common-shadow-nine flex-grow-1 tw-min-h-144-px tw-rounded-lg text-center min-w-144-px d-flex flex-column align-items-center justify-content-center animation-item"
                                            data-domain=".xyz">
                                            <img src="{{asset('assets/images/thumbs/search-domain-two-img1.png')}}" alt="Logo"
                                                class="animate__wobble" />
                                            <span
                                                class="d-block text-heading tw-mt-105 tw-text-sm fw-bold">$13.34/Yearly</span>
                                        </button>
                                        <button type="button"
                                            class="domain-item-button common-shadow-nine flex-grow-1 tw-min-h-144-px tw-rounded-lg text-center min-w-144-px d-flex flex-column align-items-center justify-content-center animation-item"
                                            data-domain=".shop">
                                            <img src="{{asset('assets/images/thumbs/search-domain-two-img2.png')}}" alt="Logo"
                                                class="animate__wobble" />
                                            <span
                                                class="d-block text-heading tw-mt-105 tw-text-sm fw-bold">$13.34/Yearly</span>
                                        </button>
                                        <button type="button"
                                            class="domain-item-button common-shadow-nine flex-grow-1 tw-min-h-144-px tw-rounded-lg text-center min-w-144-px d-flex flex-column align-items-center justify-content-center animation-item"
                                            data-domain=".icu">
                                            <img src="{{asset('assets/images/thumbs/search-domain-two-img3.png')}}" alt="Logo"
                                                class="animate__wobble" />
                                            <span
                                                class="d-block text-heading tw-mt-105 tw-text-sm fw-bold">$13.34/Yearly</span>
                                        </button>
                                        <button type="button"
                                            class="domain-item-button common-shadow-nine flex-grow-1 tw-min-h-144-px tw-rounded-lg text-center min-w-144-px d-flex flex-column align-items-center justify-content-center animation-item"
                                            data-domain=".site">
                                            <img src="{{asset('assets/images/thumbs/search-domain-two-img4.png')}}" alt="Logo"
                                                class="animate__wobble" />
                                            <span
                                                class="d-block text-heading tw-mt-105 tw-text-sm fw-bold">$13.34/Yearly</span>
                                        </button>
                                        <button type="button"
                                            class="domain-item-button common-shadow-nine flex-grow-1 tw-min-h-144-px tw-rounded-lg text-center min-w-144-px d-flex flex-column align-items-center justify-content-center animation-item"
                                            data-domain=".in">
                                            <img src="{{asset('assets/images/thumbs/search-domain-two-img5.png')}}" alt="Logo"
                                                class="animate__wobble" />
                                            <span
                                                class="d-block text-heading tw-mt-105 tw-text-sm fw-bold">$13.34/Yearly</span>
                                        </button>
                                        <button type="button"
                                            class="domain-item-button common-shadow-nine flex-grow-1 tw-min-h-144-px tw-rounded-lg text-center min-w-144-px d-flex flex-column align-items-center justify-content-center animation-item"
                                            data-domain=".gives">
                                            <img src="{{asset('assets/images/thumbs/search-domain-two-img6.png')}}" alt="Logo"
                                                class="animate__wobble" />
                                            <span
                                                class="d-block text-heading tw-mt-105 tw-text-sm fw-bold">$13.34/Yearly</span>
                                        </button>
                                    </div>
                                </div>

                                <div class="col-md-7">
                                    <div class="ps-lg-5">
                                        <div class="">
                                            <span
                                                class="tw-px-6 tw-py-1 bg-purple text-white rounded-pill fw-medium tw-mb-5">Find
                                                a new domain</span>
                                            <h4 class="tw-mb-705">
                                                Web Hosting that's fast and reliable.
                                            </h4>
                                            <p class="text-neutral-500">
                                                In today's competitive business, the demand for
                                                efficient In today's competitive cost-effective IT
                                                solutions has never been more critic. business
                                            </p>
                                        </div>
                                        <form action="#" class="d-flex tw-gap-6 flex-column flex-xl-row tw-mt-8">
                                            <div class="position-relative flex-grow-1">
                                                <input type="text"
                                                    class="tw-py-405 tw-px-705 tw-pe-100-px bg-neutral-100 tw-rounded-xl border-transparent placeholder-neutral-600 placeholder-18-px w-100"
                                                    placeholder="Enter your desire domain name" required />
                                                <select
                                                    class="select-domain form-control form-select w-auto border-0 tw-py-1 tw-pe-305 shadow-none form-select-arrow-end position-absolute tw-end-0 top-50 translate-middle-y bg-transparent tw-me-705 fw-semibold">
                                                    <option value=".xyz">.xyz</option>
                                                    <option value=".shop">.shop</option>
                                                    <option value=".icu">.icu</option>
                                                    <option value=".site">.site</option>
                                                    <option value=".in">.in</option>
                                                    <option value=".gives">.gives</option>
                                                </select>
                                            </div>
                                            <button type="submit"
                                                class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke align-items-center justify-content-center tw-gap-5 group active--translate-y-2 tw-px-15 tw-py-505 fw-semibold"
                                                data-block="button">
                                                <span class="button__flair"></span>
                                                <span class="button__label">Search</span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Search Domain Two End -->

            <!-- Pricing plan section start -->
            <section class="pricing-plan py-120">
                <div class="container">
                    <div class="max-w-672-px text-center mx-auto tw-mb-12">
                        <div class="bg-neutral-100 tw-py-3 tw-px-305 rounded-pill text-heading fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                            data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                            <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                            Up to <span class="text-yellow">70%</span> off managed cloud
                            hosting
                        </div>
                        <h2 class="splitTextStyleOne text-heading text-capitalize">
                            Pick your perfect
                            <span class="font-dm-serif fst-italic fw-normal">plan</span>
                        </h2>
                        <p class="text-neutral-500 tw-mt-5 splitTextStyleOne max-w-570-px mx-auto">
                            In today's competitive business, the demand for efficient In
                            today's competitive cost-effective IT solutions has never been
                            more critic. business
                        </p>

                        <div class="text-center" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                            data-aos-duration="800">
                            <ul class="animate-background-wrapper z-1 position-relative nav nav-pills active-text-white d-inline-flex bg-white common-shadow-four tw-p-1 rounded-pill mb-0 tw-mt-7"
                                id="pills-tabTwo" role="tablist">
                                <li class="background style-two"></li>

                                <li class="nav-item flex-grow-1" role="presentation">
                                    <button
                                        class="nav-link w-100 active-scale-094 rounded-pill tw-px-705 tw-py-205 bg-transparent fw-semibold text-neutral-600 hover-text-main-600 h-100 line-clamp-1 active"
                                        id="pills-Monthly-tab" data-bs-toggle="pill" data-bs-target="#pills-Monthly"
                                        type="button" role="tab" aria-controls="pills-Monthly"
                                        aria-selected="true">
                                        Monthly
                                    </button>
                                </li>
                                <li class="nav-item flex-grow-1" role="presentation">
                                    <button
                                        class="nav-link w-100 active-scale-094 rounded-pill tw-px-705 tw-py-205 bg-transparent fw-semibold text-neutral-600 hover-text-main-600 h-100 line-clamp-1"
                                        id="pills-Annually-tab" data-bs-toggle="pill" data-bs-target="#pills-Annually"
                                        type="button" role="tab" aria-controls="pills-Annually"
                                        aria-selected="false">
                                        Annually
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tab-content" id="pills-tabTwoContent">
                        <div class="tab-pane fade show active" id="pills-Monthly" role="tabpanel"
                            aria-labelledby="pills-Monthly-tab" tabindex="0">
                            <div class="row gy-4">
                                <div class="col-xl-4 col-sm-6" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                    data-aos-duration="600">
                                    <div
                                        class="pricing-item position-relative border border-neutral-300 tw-p-7 tw-rounded-2xl bg-white bg-white tw-duration-300 hover-border-main-600">
                                        <img src="{{asset('assets/images/shapes/arrow-curve-main.png')}}" alt="Arrow"
                                            class="position-absolute tw-end-0 top-0 tw-mt-15 tw-me-16 tw-pe-705 opacity-05" />

                                        <div class="">
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="fw-bold text-heading tw-mb-105">
                                                    <span class="text-main-600">85%</span> OFF
                                                </span>
                                                <h5 class="tw-mb-8">Basic plan</h5>
                                                <div
                                                    class="d-flex align-items-center justify-content-between tw-gap-1 tw-mb-5">
                                                    <h2 class="mb-0">
                                                        $<span class="current-price">1.99</span><span
                                                            class="tw-text-xl pricing-duration">/Monthly</span>
                                                    </h2>
                                                    <div class="form-check form-switch mb-0">
                                                        <input class="form-check-input pricing-item-toggle"
                                                            type="checkbox" role="switch" />
                                                    </div>
                                                </div>
                                                <span class="d-block fw-bold text-main-600 tw-mb-8">+2 months free</span>
                                            </div>

                                            <a href="{{route('pricing')}}"
                                                class="text-heading fw-bold tw-text-base w-100 tw-px-6 tw-py-4 tw-rounded-md border border-main-600 hover-text-white hover-bg-main-600 text-center hover--translate-y-1 active--translate-y-scale-9">
                                                See Plan & Pricing
                                            </a>
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="text-heading tw-mt-3">Renews at
                                                    <span class="text-main-600">$9.88</span>
                                                    /month</span>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>

                                                <ul class="feature-list d-flex flex-column tw-gap-6">
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon4.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unmetered bandwidth
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon5.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free SSL certificate
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon6.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free domain included
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon7.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unlimited free SSL
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tw-mt-12 d-flex justify-content-center">
                                            <button type="button"
                                                class="see-all-btn d-flex align-items-center justify-content-center tw-gap-305 text-main-600 fw-bold hover-underline d-lg-flex align-items-center tw-gap-305">
                                                See all features
                                                <i class="ph-bold ph-caret-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-sm-6" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                    data-aos-duration="700">
                                    <div
                                        class="pricing-item position-relative border border-neutral-300 tw-p-7 tw-rounded-2xl bg-white bg-white tw-duration-300 hover-border-main-600">
                                        <img src="{{asset('assets/images/shapes/arrow-curve-main.png')}}" alt="Arrow"
                                            class="position-absolute tw-end-0 top-0 tw-mt-15 tw-me-16 tw-pe-705" />

                                        <div class="">
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="fw-bold text-heading tw-mb-105">
                                                    <span class="text-main-600">85%</span> OFF
                                                </span>
                                                <h5 class="tw-mb-8">Premium plan</h5>
                                                <div
                                                    class="d-flex align-items-center justify-content-between tw-gap-1 tw-mb-5">
                                                    <h2 class="mb-0">
                                                        $<span class="current-price">10.99</span><span
                                                            class="tw-text-xl pricing-duration">/Monthly</span>
                                                    </h2>
                                                    <div class="form-check form-switch mb-0">
                                                        <input class="form-check-input pricing-item-toggle"
                                                            type="checkbox" role="switch" />
                                                    </div>
                                                </div>
                                                <span class="d-block fw-bold text-main-600 tw-mb-8">+2 months free</span>
                                            </div>

                                            <a href="{{route('pricing')}}"
                                                class="text-heading fw-bold tw-text-base w-100 tw-px-6 tw-py-4 tw-rounded-md border border-main-600 hover-text-white hover-bg-main-600 text-center hover--translate-y-1 active--translate-y-scale-9">
                                                See Plan & Pricing
                                            </a>
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="text-heading tw-mt-3">Renews at
                                                    <span class="text-main-600">$9.88</span>
                                                    /month</span>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>

                                                <ul class="feature-list d-flex flex-column tw-gap-6">
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon4.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unmetered bandwidth
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon5.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free SSL certificate
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon6.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free domain included
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon7.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unlimited free SSL
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tw-mt-12 d-flex justify-content-center">
                                            <button type="button"
                                                class="see-all-btn d-flex align-items-center justify-content-center tw-gap-305 text-main-600 fw-bold hover-underline d-lg-flex align-items-center tw-gap-305">
                                                See all features
                                                <i class="ph-bold ph-caret-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-sm-6" data-aos="fade-up"
                                    data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                    <div
                                        class="pricing-item position-relative border border-neutral-300 tw-p-7 tw-rounded-2xl bg-white bg-white tw-duration-300 hover-border-main-600">
                                        <img src="{{asset('assets/images/shapes/arrow-curve-main.png')}}" alt="Arrow"
                                            class="position-absolute tw-end-0 top-0 tw-mt-15 tw-me-16 tw-pe-705 opacity-05" />

                                        <div class="">
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="fw-bold text-heading tw-mb-105">
                                                    <span class="text-main-600">85%</span> OFF
                                                </span>
                                                <h5 class="tw-mb-8">Pro plan</h5>
                                                <div
                                                    class="d-flex align-items-center justify-content-between tw-gap-1 tw-mb-5">
                                                    <h2 class="mb-0">
                                                        $<span class="current-price">20.99</span><span
                                                            class="tw-text-xl pricing-duration">/Monthly</span>
                                                    </h2>
                                                    <div class="form-check form-switch mb-0">
                                                        <input class="form-check-input pricing-item-toggle"
                                                            type="checkbox" role="switch" />
                                                    </div>
                                                </div>
                                                <span class="d-block fw-bold text-main-600 tw-mb-8">+2 months free</span>
                                            </div>

                                            <a href="{{route('pricing')}}"
                                                class="text-heading fw-bold tw-text-base w-100 tw-px-6 tw-py-4 tw-rounded-md border border-main-600 hover-text-white hover-bg-main-600 text-center hover--translate-y-1 active--translate-y-scale-9">
                                                See Plan & Pricing
                                            </a>
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="text-heading tw-mt-3">Renews at
                                                    <span class="text-main-600">$9.88</span>
                                                    /month</span>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>

                                                <ul class="feature-list d-flex flex-column tw-gap-6">
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon4.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unmetered bandwidth
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon5.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free SSL certificate
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon6.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free domain included
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon7.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unlimited free SSL
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tw-mt-12 d-flex justify-content-center">
                                            <button type="button"
                                                class="see-all-btn d-flex align-items-center justify-content-center tw-gap-305 text-main-600 fw-bold hover-underline d-lg-flex align-items-center tw-gap-305">
                                                See all features
                                                <i class="ph-bold ph-caret-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-Annually" role="tabpanel"
                            aria-labelledby="pills-Annually-tab" tabindex="0">
                            <div class="row gy-4">
                                <div class="col-xl-4 col-sm-6" data-aos="fade-up"
                                    data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                    <div
                                        class="pricing-item position-relative border border-neutral-300 tw-p-7 tw-rounded-2xl bg-white bg-white tw-duration-300 hover-border-main-600">
                                        <img src="{{asset('assets/images/shapes/arrow-curve-main.png')}}" alt="Arrow"
                                            class="position-absolute tw-end-0 top-0 tw-mt-15 tw-me-16 tw-pe-705 opacity-05" />

                                        <div class="">
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="fw-bold text-heading tw-mb-105">
                                                    <span class="text-main-600">85%</span> OFF
                                                </span>
                                                <h5 class="tw-mb-8">Basic plan</h5>
                                                <div
                                                    class="d-flex align-items-center justify-content-between tw-gap-1 tw-mb-5">
                                                    <h2 class="mb-0">
                                                        $<span class="current-price">19.90</span><span
                                                            class="tw-text-xl pricing-duration">/Yearly</span>
                                                    </h2>
                                                    <div class="form-check form-switch mb-0">
                                                        <input class="form-check-input pricing-item-toggle"
                                                            type="checkbox" role="switch" />
                                                    </div>
                                                </div>
                                                <span class="d-block fw-bold text-main-600 tw-mb-8">+2 months free</span>
                                            </div>

                                            <a href="{{route('pricing')}}"
                                                class="text-heading fw-bold tw-text-base w-100 tw-px-6 tw-py-4 tw-rounded-md border border-main-600 hover-text-white hover-bg-main-600 text-center hover--translate-y-1 active--translate-y-scale-9">
                                                See Plan & Pricing
                                            </a>
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="text-heading tw-mt-3">Renews at
                                                    <span class="text-main-600">$9.88</span>
                                                    /month</span>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>

                                                <ul class="feature-list d-flex flex-column tw-gap-6">
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon4.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unmetered bandwidth
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon5.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free SSL certificate
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon6.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free domain included
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon7.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unlimited free SSL
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tw-mt-12 d-flex justify-content-center">
                                            <button type="button"
                                                class="see-all-btn d-flex align-items-center justify-content-center tw-gap-305 text-main-600 fw-bold hover-underline d-lg-flex align-items-center tw-gap-305">
                                                See all features
                                                <i class="ph-bold ph-caret-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-sm-6" data-aos="fade-up"
                                    data-aos-anchor-placement="top-bottom" data-aos-duration="700">
                                    <div
                                        class="pricing-item position-relative border border-neutral-300 tw-p-7 tw-rounded-2xl bg-white bg-white tw-duration-300 hover-border-main-600">
                                        <img src="{{asset('assets/images/shapes/arrow-curve-main.png')}}" alt="Arrow"
                                            class="position-absolute tw-end-0 top-0 tw-mt-15 tw-me-16 tw-pe-705" />

                                        <div class="">
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="fw-bold text-heading tw-mb-105">
                                                    <span class="text-main-600">85%</span> OFF
                                                </span>
                                                <h5 class="tw-mb-8">Premium plan</h5>
                                                <div
                                                    class="d-flex align-items-center justify-content-between tw-gap-1 tw-mb-5">
                                                    <h2 class="mb-0">
                                                        $<span class="current-price">109.90</span><span
                                                            class="tw-text-xl pricing-duration">/Yearly</span>
                                                    </h2>
                                                    <div class="form-check form-switch mb-0">
                                                        <input class="form-check-input pricing-item-toggle"
                                                            type="checkbox" role="switch" />
                                                    </div>
                                                </div>
                                                <span class="d-block fw-bold text-main-600 tw-mb-8">+2 months free</span>
                                            </div>

                                            <a href="{{route('pricing')}}"
                                                class="text-heading fw-bold tw-text-base w-100 tw-px-6 tw-py-4 tw-rounded-md border border-main-600 hover-text-white hover-bg-main-600 text-center hover--translate-y-1 active--translate-y-scale-9">
                                                See Plan & Pricing
                                            </a>
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="text-heading tw-mt-3">Renews at
                                                    <span class="text-main-600">$9.88</span>
                                                    /month</span>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>

                                                <ul class="feature-list d-flex flex-column tw-gap-6">
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon4.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unmetered bandwidth
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon5.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free SSL certificate
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon6.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free domain included
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon7.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unlimited free SSL
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tw-mt-12 d-flex justify-content-center">
                                            <button type="button"
                                                class="see-all-btn d-flex align-items-center justify-content-center tw-gap-305 text-main-600 fw-bold hover-underline d-lg-flex align-items-center tw-gap-305">
                                                See all features
                                                <i class="ph-bold ph-caret-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-sm-6" data-aos="fade-up"
                                    data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                    <div
                                        class="pricing-item position-relative border border-neutral-300 tw-p-7 tw-rounded-2xl bg-white bg-white tw-duration-300 hover-border-main-600">
                                        <img src="{{asset('assets/images/shapes/arrow-curve-main.png')}}" alt="Arrow"
                                            class="position-absolute tw-end-0 top-0 tw-mt-15 tw-me-16 tw-pe-705 opacity-05" />

                                        <div class="">
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="fw-bold text-heading tw-mb-105">
                                                    <span class="text-main-600">85%</span> OFF
                                                </span>
                                                <h5 class="tw-mb-8">Pro plan</h5>
                                                <div
                                                    class="d-flex align-items-center justify-content-between tw-gap-1 tw-mb-5">
                                                    <h2 class="mb-0">
                                                        $<span class="current-price">209.90</span><span
                                                            class="tw-text-xl pricing-duration">/Yearly</span>
                                                    </h2>
                                                    <div class="form-check form-switch mb-0">
                                                        <input class="form-check-input pricing-item-toggle"
                                                            type="checkbox" role="switch" />
                                                    </div>
                                                </div>
                                                <span class="d-block fw-bold text-main-600 tw-mb-8">+2 months free</span>
                                            </div>

                                            <a href="{{route('pricing')}}"
                                                class="text-heading fw-bold tw-text-base w-100 tw-px-6 tw-py-4 tw-rounded-md border border-main-600 hover-text-white hover-bg-main-600 text-center hover--translate-y-1 active--translate-y-scale-9">
                                                See Plan & Pricing
                                            </a>
                                            <div class="tw-ps-205 tw-pt-205">
                                                <span class="text-heading tw-mt-3">Renews at
                                                    <span class="text-main-600">$9.88</span>
                                                    /month</span>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>

                                                <ul class="feature-list d-flex flex-column tw-gap-6">
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon4.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unmetered bandwidth
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon5.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free SSL certificate
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon6.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free domain included
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon7.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Unlimited free SSL
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon1.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Single website </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon2.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">One-click WordPress installs
                                                        </span>
                                                    </li>
                                                    <li class="d-flex align-items-center tw-gap-305 fw-medium">
                                                        <span class="">
                                                            <img src="{{asset('assets/images/icons/pricing-icon3.svg')}}"
                                                                alt="img" />
                                                        </span>
                                                        <span class="text-heading">Free WordPress website transfer
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tw-mt-12 d-flex justify-content-center">
                                            <button type="button"
                                                class="see-all-btn d-flex align-items-center justify-content-center tw-gap-305 text-main-600 fw-bold hover-underline d-lg-flex align-items-center tw-gap-305">
                                                See all features
                                                <i class="ph-bold ph-caret-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Pricing plan section End -->

            <!-- Services section start -->
            <section class="services py-120 position-relative z-1 gradient-bg-two">
                <img src="{{asset('assets/images/shapes/rope-shape.png')}}" alt="Rope"
                    class="position-absolute tw-start-0 tw-ms-80-px tw-mt-16 top-0 z-n1" />
                <img src="{{asset('assets/images/shapes/matherboard-shape.png')}}" alt="Shape"
                    class="position-absolute top-0 tw-start-0 tw-mt-160-px tw-ms-128-px d-lg-block d-none z-n1 opacity-1" />

                <div class="container max-w-1552-px">
                    <div class="max-w-672-px text-center mx-auto tw-mb-12">
                        <div class="bg-white-06 tw-py-3 tw-px-305 rounded-pill text-white fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max aos-init aos-animate"
                            data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                            <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                            Up to <span class="text-yellow">70%</span> off managed cloud
                            hosting
                        </div>
                        <h2 class="splitTextStyleOne text-white">
                            Speed.
                            <span class="font-dm-serif fst-italic fw-normal">
                                Reliability</span>. Efficiency.
                        </h2>
                        <p class="text-neutral-300 tw-mt-5 splitTextStyleOne max-w-570-px mx-auto">
                            In today's competitive business, the demand for efficient In
                            today's competitive cost-effective IT solutions has never been
                            more critic. business
                        </p>
                    </div>

                    <div class="service-slider swiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide tw-pb-105" data-aos="fade-up"
                                data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                <div
                                    class="square-bg-shape position-relative tw-rounded-2xl z-1 animation-item tw-h-424-px">
                                    <div
                                        class="service-item bg-white hover-bg-main-600 group group-item tw-py-16 tw-ps-10 tw-pe-4 tw-rounded-2xl h-100 d-flex flex-column justify-content-center tw-duration-200">
                                        <span class="tw-mb-13 group-hover-item-text-invert">
                                            <img src="{{asset('assets/images/icons/service-icon1.svg')}}" alt="Icon"
                                                class="animate__heartBeat" />
                                        </span>
                                        <div class="">
                                            <div class="group-hover-item-d-none tw-mb-4">
                                                <span
                                                    class="tw-py-1 tw-px-305 rounded-pill bg-main-50 text-uppercase text-neutral-500 tw-text-xs fw-semibold group-hover-text-white tw-duration-200 group-hover-bg-main-two-600">Easy
                                                    Invoicing</span>
                                            </div>
                                            <h5 class="group-hover-text-white tw-duration-200 max-w-250-px">
                                                Local data centers. Around the world.
                                            </h5>
                                            <p
                                                class="text-neutral-300 tw-mt-3 line-clamp-2 d-none group-hover-item-d-block">
                                                Web hosting provides everything you idea online. From
                                                where your website
                                            </p>
                                            <a href="javascript:void(0)"
                                                class="d-flex align-items-center tw-gap-205 text-main-600 fw-bold d-lg-flex align-items-center tw-gap-305 group-hover-text-white tw-duration-200 tw-mt-6 tw-transition-0">
                                                Learn More
                                                <i class="ph ph-arrow-right tw-text-sm"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide tw-pb-105" data-aos="fade-up"
                                data-aos-anchor-placement="top-bottom" data-aos-duration="700">
                                <div
                                    class="square-bg-shape position-relative tw-rounded-2xl z-1 animation-item tw-h-424-px">
                                    <div
                                        class="service-item bg-white hover-bg-main-600 group group-item tw-py-16 tw-ps-10 tw-pe-4 tw-rounded-2xl h-100 d-flex flex-column justify-content-center tw-duration-200">
                                        <span class="tw-mb-13 group-hover-item-text-invert">
                                            <img src="{{asset('assets/images/icons/service-icon2.svg')}}" alt="Icon"
                                                class="animate__heartBeat" />
                                        </span>
                                        <div class="">
                                            <div class="group-hover-item-d-none tw-mb-4">
                                                <span
                                                    class="tw-py-1 tw-px-305 rounded-pill bg-main-50 text-uppercase text-neutral-500 tw-text-xs fw-semibold group-hover-text-white tw-duration-200 group-hover-bg-main-two-600">Easy
                                                    Invoicing</span>
                                            </div>
                                            <h5 class="group-hover-text-white tw-duration-200 max-w-250-px">
                                                Full speed ahead. Whatever the traffic.
                                            </h5>
                                            <p
                                                class="text-neutral-300 tw-mt-3 line-clamp-2 d-none group-hover-item-d-block">
                                                Web hosting provides everything you idea online. From
                                                where your website
                                            </p>
                                            <a href="javascript:void(0)"
                                                class="d-flex align-items-center tw-gap-205 text-main-600 fw-bold d-lg-flex align-items-center tw-gap-305 group-hover-text-white tw-duration-200 tw-mt-6 tw-transition-0">
                                                Learn More
                                                <i class="ph ph-arrow-right tw-text-sm"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide tw-pb-105" data-aos="fade-up"
                                data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                <div
                                    class="square-bg-shape position-relative tw-rounded-2xl z-1 animation-item tw-h-424-px">
                                    <div
                                        class="service-item bg-white hover-bg-main-600 group group-item tw-py-16 tw-ps-10 tw-pe-4 tw-rounded-2xl h-100 d-flex flex-column justify-content-center tw-duration-200">
                                        <span class="tw-mb-13 group-hover-item-text-invert">
                                            <img src="{{asset('assets/images/icons/service-icon3.svg')}}" alt="Icon"
                                                class="animate__heartBeat" />
                                        </span>
                                        <div class="">
                                            <div class="group-hover-item-d-none tw-mb-4">
                                                <span
                                                    class="tw-py-1 tw-px-305 rounded-pill bg-main-50 text-uppercase text-neutral-500 tw-text-xs fw-semibold group-hover-text-white tw-duration-200 group-hover-bg-main-two-600">Easy
                                                    Invoicing</span>
                                            </div>
                                            <h5 class="group-hover-text-white tw-duration-200 max-w-250-px">
                                                Live and kicking. 24/7.
                                            </h5>
                                            <p
                                                class="text-neutral-300 tw-mt-3 line-clamp-2 d-none group-hover-item-d-block">
                                                Web hosting provides everything you idea online. From
                                                where your website
                                            </p>
                                            <a href="javascript:void(0)"
                                                class="d-flex align-items-center tw-gap-205 text-main-600 fw-bold d-lg-flex align-items-center tw-gap-305 group-hover-text-white tw-duration-200 tw-mt-6 tw-transition-0">
                                                Learn More
                                                <i class="ph ph-arrow-right tw-text-sm"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide tw-pb-105" data-aos="fade-up"
                                data-aos-anchor-placement="top-bottom" data-aos-duration="900">
                                <div
                                    class="square-bg-shape position-relative tw-rounded-2xl z-1 animation-item tw-h-424-px">
                                    <div
                                        class="service-item bg-white hover-bg-main-600 group group-item tw-py-16 tw-ps-10 tw-pe-4 tw-rounded-2xl h-100 d-flex flex-column justify-content-center tw-duration-200">
                                        <span class="tw-mb-13 group-hover-item-text-invert">
                                            <img src="{{asset('assets/images/icons/service-icon4.svg')}}" alt="Icon"
                                                class="animate__heartBeat" />
                                        </span>
                                        <div class="">
                                            <div class="group-hover-item-d-none tw-mb-4">
                                                <span
                                                    class="tw-py-1 tw-px-305 rounded-pill bg-main-50 text-uppercase text-neutral-500 tw-text-xs fw-semibold group-hover-text-white tw-duration-200 group-hover-bg-main-two-600">Easy
                                                    Invoicing</span>
                                            </div>
                                            <h5 class="group-hover-text-white tw-duration-200 max-w-250-px">
                                                Website migration. Made simple.
                                            </h5>
                                            <p
                                                class="text-neutral-300 tw-mt-3 line-clamp-2 d-none group-hover-item-d-block">
                                                Web hosting provides everything you idea online. From
                                                where your website
                                            </p>
                                            <a href="javascript:void(0)"
                                                class="d-flex align-items-center tw-gap-205 text-main-600 fw-bold d-lg-flex align-items-center tw-gap-305 group-hover-text-white tw-duration-200 tw-mt-6 tw-transition-0">
                                                Learn More
                                                <i class="ph ph-arrow-right tw-text-sm"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide tw-pb-105" data-aos="fade-up"
                                data-aos-anchor-placement="top-bottom" data-aos-duration="1000">
                                <div
                                    class="square-bg-shape position-relative tw-rounded-2xl z-1 animation-item tw-h-424-px">
                                    <div
                                        class="service-item bg-white hover-bg-main-600 group group-item tw-py-16 tw-ps-10 tw-pe-4 tw-rounded-2xl h-100 d-flex flex-column justify-content-center tw-duration-200">
                                        <span class="tw-mb-13 group-hover-item-text-invert">
                                            <img src="{{asset('assets/images/icons/service-icon3.svg')}}" alt="Icon"
                                                class="animate__heartBeat" />
                                        </span>
                                        <div class="">
                                            <div class="group-hover-item-d-none tw-mb-4">
                                                <span
                                                    class="tw-py-1 tw-px-305 rounded-pill bg-main-50 text-uppercase text-neutral-500 tw-text-xs fw-semibold group-hover-text-white tw-duration-200 group-hover-bg-main-two-600">Easy
                                                    Invoicing</span>
                                            </div>
                                            <h5 class="group-hover-text-white tw-duration-200 max-w-250-px">
                                                Live and kicking. 24/7.
                                            </h5>
                                            <p
                                                class="text-neutral-300 tw-mt-3 line-clamp-2 d-none group-hover-item-d-block">
                                                Web hosting provides everything you idea online. From
                                                where your website
                                            </p>
                                            <a href="javascript:void(0)"
                                                class="d-flex align-items-center tw-gap-205 text-main-600 fw-bold d-lg-flex align-items-center tw-gap-305 group-hover-text-white tw-duration-200 tw-mt-6 tw-transition-0">
                                                Learn More
                                                <i class="ph ph-arrow-right tw-text-sm"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div
                        class="service-slider-pagination pagination-style-two d-lg-non d-flex align-items-center justify-content-center tw-mt-605">
                    </div>
                </div>
            </section>
            <!-- Services section End -->

            <div class="overflow-hidden gradient-bg-four">
                <!-- Brand Marketing Section Start -->
                <section class="brand-marketing py-120">
                    <div class="container">
                        <div class="row gy-5">
                            <div class="col-md-6">
                                <div class="ps-5 position-relative pe-lg-5 tw-pb-4 h-100">
                                    <div class="tw-rounded-28-px overflow-hidden h-100">
                                        <img src="{{asset('assets/images/thumbs/brand-marketing-img.png')}}" alt="Image"
                                            class="w-100 h-100 object-fit-cover" />
                                    </div>

                                    <img src="{{asset('assets/images/shapes/finger-shape.png')}}" alt="Shape"
                                        class="flower animate__wobble__two position-absolute tw-end-100 bottom-100 tw--m-24-px z-n1" />
                                    <span
                                        class="tw-w-705 tw-h-705 bg-yellow rounded-circle position-absolute tw-end-100 top-0 tw-mt-105-px opacity-50"></span>
                                    <div
                                        class="bg-white tw-rounded-lg tw-p-5 max-w-218-px position-absolute tw-start-0 bottom-0 w-100 tw--mt-8-px tw--me-8-px common-shadow-two z-1">
                                        <div
                                            class="d-inline-flex align-items-center tw-gap-1 bg-main-600 tw-py-05 tw-px-3 rounded-pill position-absolute top-0 tw-end-0 tw--mt-12-px tw--me-12-px">
                                            <span class="text-white fw-bold tw-text-sm">4.9</span>
                                            <span class="text-white d-flex">
                                                <img src="{{asset('assets/images/icons/star.svg')}}" alt="img" />
                                            </span>
                                        </div>
                                        <img src="{{asset('assets/images/icons/ratings.svg')}}" alt="img" class="" />
                                        <div
                                            class="tw-mt-3 d-flex align-items-center justify-content-between max-w-154-px">
                                            <span class="tw-text-lg text-heading fw-semibold">Trust pilot</span>
                                            <img src="{{asset('assets/images/icons/verified-icon.svg')}}" alt="img" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="">
                                    <div class="bg-neutral-100 tw-py-3 tw-px-305 rounded-pill text-heading fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="600">
                                        <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                                        Up to <span class="text-yellow">70%</span> off managed
                                        cloud hosting
                                    </div>
                                    <h2 class="splitTextStyleOne text-heading text-capitalize">
                                        Grow your brand with sass
                                        <span class="font-dm-serif fst-italic fw-normal">Websites +</span>
                                        Marketing.
                                    </h2>
                                    <p
                                        class="splitTextStyleOne text-neutral-500 tw-mt-8 max-w-570-px fw-medium tw-text-lg">
                                        In today's competitive business, the demand for efficient
                                        In today's competitive cost-effective IT solutions has
                                        never been more critic. business
                                    </p>

                                    <div class="tw-mt-11 d-flex flex-column tw-gap-8">
                                        <div class="d-flex align-items-start tw-gap-5" data-aos="fade-up"
                                            data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                            <span
                                                class="tw-h-505 tw-w-505 bg-main-600 text-white tw-text-sm d-flex justify-content-center align-items-center rounded-circle tw-mt-105 flex-shrink-0">
                                                <i class="ph ph-check"></i>
                                            </span>
                                            <p class="tw-text-lg fw-medium text-heading max-w-444-px flex-grow-1">
                                                Secure your files with regular automatic backups and
                                                two-factor authentication
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-start tw-gap-5" data-aos="fade-up"
                                            data-aos-anchor-placement="top-bottom" data-aos-duration="700">
                                            <span
                                                class="tw-h-505 tw-w-505 bg-main-600 text-white tw-text-sm d-flex justify-content-center align-items-center rounded-circle tw-mt-105 flex-shrink-0">
                                                <i class="ph ph-check"></i>
                                            </span>
                                            <p class="tw-text-lg fw-medium text-heading max-w-444-px flex-grow-1">
                                                Encrypt your website traffic with unlimited SSL
                                                security certificates
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-start tw-gap-5" data-aos="fade-up"
                                            data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                            <span
                                                class="tw-h-505 tw-w-505 bg-main-600 text-white tw-text-sm d-flex justify-content-center align-items-center rounded-circle tw-mt-105 flex-shrink-0">
                                                <i class="ph ph-check"></i>
                                            </span>
                                            <p class="tw-text-lg fw-medium text-heading max-w-444-px flex-grow-1">
                                                Enjoy full protection from DDoS attacks with
                                                Cloudflare protected nameservers
                                            </p>
                                        </div>
                                    </div>

                                    <div class="tw-mt-12" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="900">
                                        <a href="{{route('register')}}"
                                            class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke tw-gap-5 group active--translate-y-2 tw-px-17 rounded-pill tw-py-505 fw-medium"
                                            data-block="button">
                                            <span class="button__flair"></span>
                                            <span class="button__label">Get Started</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Brand Marketing Section End -->

                <!-- Website Owner section start -->
                <section class="website-owner pb-120 position-relative z-1">
                    <img src="{{asset('assets/images/shapes/moon-shape.png')}}" alt="Moon Shape"
                        class="position-absolute top-50 tw-start-50 translate-middle z-n1" />

                    <div class="container">
                        <div class="d-flex align-items-center justify-content-between tw-gap-6 tw-mb-12">
                            <div class="max-w-672-px">
                                <div class="bg-neutral-200 tw-py-3 tw-px-305 rounded-pill text-heading fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                                    data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                    <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                                    Up to <span class="text-yellow">70%</span> off managed cloud
                                    hosting
                                </div>
                                <h2 class="splitTextStyleOne text-heading text-capitalize">
                                    Trusted by 3+ million website owners
                                    <span class="font-dm-serif fst-italic fw-normal">
                                        worldwide
                                    </span>
                                </h2>
                            </div>
                            <div class="" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                data-aos-duration="800">
                                <p class="splitTextStyleOne text-neutral-500 tw-mt-8 max-w-490-px fw-medium">
                                    In today's competitive business, the demand for efficient In
                                    today's competitive cost-effective IT solutions has never
                                    been more critic.
                                </p>
                            </div>
                        </div>

                        <div class="row gy-4">
                            <div class="col-lg-4">
                                <div class="row gy-4">
                                    <div class="col-lg-12 col-md-6" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                        <div
                                            class="common-shadow-ten tw-rounded-2xl tw-p-10 tw-pe-9 bg-white h-100 animation-item">
                                            <span class="tw-mb-5">
                                                <img src="{{asset('assets/images/thumbs/website-owner-img1.png')}}" alt="Logo"
                                                    class="animate__flipInY" />
                                            </span>
                                            <div class="">
                                                <p class="text-neutral-500 tw-text-xl">
                                                    We get absolutely raving reviews from our sales and
                                                    customer support teams using close. Even our co-
                                                    sales founders are very happy. We get absolutely
                                                    raving reviews from our Even our co- founders are
                                                    very happy for services
                                                </p>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="">
                                                        <h6 class="tw-text-lg tw-mb-205">Rudra Ghosh</h6>
                                                        <span class="text-neutral-500">
                                                            Founder & CEO
                                                            <span class="text-main-600">Dulalix</span>
                                                        </span>
                                                    </div>
                                                    <div
                                                        class="d-inline-flex align-items-center tw-gap-1 bg-main-600 tw-py-05 tw-px-3 rounded-pill">
                                                        <span class="text-white fw-bold tw-text-sm">4.9</span>
                                                        <span class="text-white d-flex">
                                                            <img src="{{asset('assets/images/icons/star.svg')}}" alt="img" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                        <div
                                            class="common-shadow-ten tw-rounded-2xl tw-p-10 tw-pe-9 bg-white h-100 animation-item">
                                            <span class="tw-mb-5">
                                                <img src="{{asset('assets/images/thumbs/website-owner-img2.png')}}" alt="Logo"
                                                    class="animate__flipInY" />
                                            </span>
                                            <div class="">
                                                <p class="text-neutral-500 tw-text-xl">
                                                    We get absolutely raving reviews from our sales and
                                                    customer support teams using close. Even our co
                                                </p>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="">
                                                        <h6 class="tw-text-lg tw-mb-205">Rudra Ghosh</h6>
                                                        <span class="text-neutral-500">
                                                            Founder & CEO
                                                            <span class="text-main-600">Dulalix</span>
                                                        </span>
                                                    </div>
                                                    <div
                                                        class="d-inline-flex align-items-center tw-gap-1 bg-main-600 tw-py-05 tw-px-3 rounded-pill">
                                                        <span class="text-white fw-bold tw-text-sm">4.9</span>
                                                        <span class="text-white d-flex">
                                                            <img src="{{asset('assets/images/icons/star.svg')}}" alt="img" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="row gy-4">
                                    <div class="col-lg-12 col-md-6" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="700">
                                        <div
                                            class="common-shadow-ten tw-rounded-2xl tw-p-10 tw-pe-9 bg-white h-100 animation-item">
                                            <span class="tw-mb-5">
                                                <img src="{{asset('assets/images/thumbs/website-owner-img3.png')}}" alt="Logo"
                                                    class="animate__flipInY" />
                                            </span>
                                            <div class="">
                                                <p class="text-neutral-500 tw-text-xl">
                                                    We get absolutely raving reviews from our sales and
                                                    customer support teams using close. Even our
                                                    co-founders are very happy.
                                                </p>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="">
                                                        <h6 class="tw-text-lg tw-mb-205">Rudra Ghosh</h6>
                                                        <span class="text-neutral-500">
                                                            Founder & CEO
                                                            <span class="text-main-600">Dulalix</span>
                                                        </span>
                                                    </div>
                                                    <div
                                                        class="d-inline-flex align-items-center tw-gap-1 bg-main-600 tw-py-05 tw-px-3 rounded-pill">
                                                        <span class="text-white fw-bold tw-text-sm">4.9</span>
                                                        <span class="text-white d-flex">
                                                            <img src="{{asset('assets/images/icons/star.svg')}}" alt="img" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="700">
                                        <div
                                            class="common-shadow-ten tw-rounded-2xl tw-p-10 tw-pe-9 bg-white h-100 animation-item">
                                            <span class="tw-mb-5">
                                                <img src="{{asset('assets/images/thumbs/website-owner-img4.png')}}" alt="Logo"
                                                    class="animate__flipInY" />
                                            </span>
                                            <div class="">
                                                <p class="text-neutral-500 tw-text-xl">
                                                    We get absolutely raving reviews from our sales and
                                                    customer support teams using close. Even our co-
                                                    sales founders are very happy. We get absolutely
                                                    raving reviews from our
                                                </p>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="">
                                                        <h6 class="tw-text-lg tw-mb-205">Rudra Ghosh</h6>
                                                        <span class="text-neutral-500">
                                                            Founder & CEO
                                                            <span class="text-main-600">Dulalix</span>
                                                        </span>
                                                    </div>
                                                    <div
                                                        class="d-inline-flex align-items-center tw-gap-1 bg-main-600 tw-py-05 tw-px-3 rounded-pill">
                                                        <span class="text-white fw-bold tw-text-sm">4.9</span>
                                                        <span class="text-white d-flex">
                                                            <img src="{{asset('assets/images/icons/star.svg')}}" alt="img" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="row gy-4">
                                    <div class="col-lg-12 col-md-6" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                        <div
                                            class="common-shadow-ten tw-rounded-2xl tw-p-10 tw-pe-9 bg-white h-100 animation-item">
                                            <span class="tw-mb-5">
                                                <img src="{{asset('assets/images/thumbs/website-owner-img5.png')}}" alt="Logo"
                                                    class="animate__flipInY" />
                                            </span>
                                            <div class="">
                                                <p class="text-neutral-500 tw-text-xl">
                                                    We get absolutely raving reviews from our sales and
                                                    customer support teams using close. Even our co-
                                                    sales founders are very happy. We get absolutely
                                                    raving reviews from our Even our co- founders are
                                                    very happy for services
                                                </p>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="">
                                                        <h6 class="tw-text-lg tw-mb-205">Rudra Ghosh</h6>
                                                        <span class="text-neutral-500">
                                                            Founder & CEO
                                                            <span class="text-main-600">Dulalix</span>
                                                        </span>
                                                    </div>
                                                    <div
                                                        class="d-inline-flex align-items-center tw-gap-1 bg-main-600 tw-py-05 tw-px-3 rounded-pill">
                                                        <span class="text-white fw-bold tw-text-sm">4.9</span>
                                                        <span class="text-white d-flex">
                                                            <img src="{{asset('assets/images/icons/star.svg')}}" alt="img" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6" data-aos="fade-up"
                                        data-aos-anchor-placement="top-bottom" data-aos-duration="800">
                                        <div
                                            class="common-shadow-ten tw-rounded-2xl tw-p-10 tw-pe-9 bg-white h-100 animation-item">
                                            <span class="tw-mb-5">
                                                <img src="{{asset('assets/images/thumbs/website-owner-img6.png')}}" alt="Logo"
                                                    class="animate__flipInY" />
                                            </span>
                                            <div class="">
                                                <p class="text-neutral-500 tw-text-xl">
                                                    We get absolutely raving reviews from our sales and
                                                    customer support teams using close. Even our compa
                                                </p>
                                                <span class="d-block tw-h-px bg-neutral-100 tw-my-6"></span>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="">
                                                        <h6 class="tw-text-lg tw-mb-205">Rudra Ghosh</h6>
                                                        <span class="text-neutral-500">
                                                            Founder & CEO
                                                            <span class="text-main-600">Dulalix</span>
                                                        </span>
                                                    </div>
                                                    <div
                                                        class="d-inline-flex align-items-center tw-gap-1 bg-main-600 tw-py-05 tw-px-3 rounded-pill">
                                                        <span class="text-white fw-bold tw-text-sm">4.9</span>
                                                        <span class="text-white d-flex">
                                                            <img src="{{asset('assets/images/icons/star.svg')}}" alt="img" />
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tw-mt-13 text-center" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                            data-aos-duration="900">
                            <a href="javascript:void(0)"
                                class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke tw-gap-5 group active--translate-y-2 tw-px-17 rounded-pill tw-py-505 fw-medium"
                                data-block="button">
                                <span class="button__flair"></span>
                                <span class="button__label">Read More Story</span>
                            </a>
                        </div>
                    </div>
                </section>
                <!-- Website Owner section End -->
            </div>

            <!-- Faq Two Section Start -->
            <section class="faq-two py-120">
                <div class="container">
                    <div class="row gy-4">
                        <div class="col-lg-4">
                            <div class="">
                                <div class="bg-neutral-100 tw-py-3 tw-px-305 rounded-pill text-heading fw-medium text-capitalize tw-leading-none d-inline-flex align-items-center tw-gap-2 tw-mb-405 min-w-max"
                                    data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="600">
                                    <span class="tw-w-205 tw-h-205 bg-yellow rounded-circle"></span>
                                    Up to <span class="text-yellow">70%</span> off managed cloud
                                    hosting
                                </div>
                                <h2 class="splitTextStyleOne text-heading text-capitalize">
                                    Frequently ask
                                    <span class="font-dm-serif fst-italic fw-normal">Questions</span>
                                </h2>
                                <p class="splitTextStyleOne text-neutral-500 tw-mt-8 max-w-350-px fw-medium">
                                    In today's competitive business, the demand for efficient In
                                    today's competitive cost-effective
                                </p>

                                <div class="tw-mt-9" data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                    data-aos-duration="900">
                                    <a href="javascript:void(0)"
                                        class="hover--translate-y-1 active--translate-y-scale-9 btn btn-main hover-style-one button--stroke tw-gap-5 group active--translate-y-2 tw-px-17 rounded-pill tw-py-505 fw-medium"
                                        data-block="button">
                                        <span class="button__flair"></span>
                                        <span class="button__label">Clients Area</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="ps-xl-5">
                                <div class="accordion common-accordion style-two" id="accordionExample">
                                    <div class="accordion-item tw-py-8 tw-px-40-px tw-rounded-xl bg-transparent border-0 mb-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="800">
                                        <h5
                                            class="accordion-header d-flex align-items-center justify-content-between tw-gap-3">
                                            <button
                                                class="accordion-button shadow-none p-0 line-clamp-3 bg-transparent h5 collapsed"
                                                type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                aria-expanded="false" aria-controls="collapseTwo">
                                                How does GoDaddy help small business owners succeed?
                                            </button>
                                        </h5>
                                        <div id="collapseTwo" class="accordion-collapse collapse"
                                            data-bs-parent="#accordionExample">
                                            <div class="accordion-body p-0 tw-mt-605 max-w-620-px">
                                                <p class="text-neutral-500">
                                                    GoDaddy offers more than just a platform to build
                                                    your website, we offer everything you need to create
                                                    an effective, memorable online presence. Already
                                                    have a site? We offer hosting plans that will keep
                                                    it fast, secure and online. Our professional
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item tw-py-8 tw-px-40-px tw-rounded-xl bg-transparent border-0 mb-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="800">


                                        <h5
                                            class="accordion-header d-flex align-items-center justify-content-between tw-gap-3">
                                            <button
                                                class="accordion-button shadow-none p-0 line-clamp-3 bg-transparent h5"
                                                type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                aria-expanded="true" aria-controls="collapseOne">
                                                Why do I need a website for my business?
                                            </button>
                                        </h5>
                                        <div id="collapseOne" class="accordion-collapse collapse show"
                                            data-bs-parent="#accordionExample">
                                            <div class="accordion-body p-0 tw-mt-605 max-w-620-px">
                                                <p class="text-neutral-500">
                                                    GoDaddy offers more than just a platform to build
                                                    your website, we offer everything you need to create
                                                    an effective, memorable online presence. Already
                                                    have a site? We offer hosting plans that will keep
                                                    it fast, secure and online. Our professional
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item tw-py-8 tw-px-40-px tw-rounded-xl bg-transparent border-0 mb-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="800">
                                        <h5
                                            class="accordion-header d-flex align-items-center justify-content-between tw-gap-3">
                                            <button
                                                class="accordion-button shadow-none p-0 line-clamp-3 bg-transparent h5 collapsed"
                                                type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapseThree" aria-expanded="false"
                                                aria-controls="collapseThree">
                                                Why do I need a professional email?
                                            </button>
                                        </h5>
                                        <div id="collapseThree" class="accordion-collapse collapse"
                                            data-bs-parent="#accordionExample">
                                            <div class="accordion-body p-0 tw-mt-605 max-w-620-px">
                                                <p class="text-neutral-500">
                                                    GoDaddy offers more than just a platform to build
                                                    your website, we offer everything you need to create
                                                    an effective, memorable online presence. Already
                                                    have a site? We offer hosting plans that will keep
                                                    it fast, secure and online. Our professional
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item tw-py-8 tw-px-40-px tw-rounded-xl bg-transparent border-0 mb-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="800">
                                        <h5
                                            class="accordion-header d-flex align-items-center justify-content-between tw-gap-3">
                                            <button
                                                class="accordion-button shadow-none p-0 line-clamp-3 bg-transparent h5 collapsed"
                                                type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapseFour" aria-expanded="false"
                                                aria-controls="collapseFour">
                                                What makes GoDaddy Web Hosting the world leader?
                                            </button>
                                        </h5>
                                        <div id="collapseFour" class="accordion-collapse collapse"
                                            data-bs-parent="#accordionExample">
                                            <div class="accordion-body p-0 tw-mt-605 max-w-620-px">
                                                <p class="text-neutral-500">
                                                    GoDaddy offers more than just a platform to build
                                                    your website, we offer everything you need to create
                                                    an effective, memorable online presence. Already
                                                    have a site? We offer hosting plans that will keep
                                                    it fast, secure and online. Our professional
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item tw-py-8 tw-px-40-px tw-rounded-xl bg-transparent border-0 mb-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="800">
                                        <h5
                                            class="accordion-header d-flex align-items-center justify-content-between tw-gap-3">
                                            <button
                                                class="accordion-button shadow-none p-0 line-clamp-3 bg-transparent h5 collapsed"
                                                type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapseFive" aria-expanded="false"
                                                aria-controls="collapseFive">
                                                Why choose GoDaddy for WordPress?
                                            </button>
                                        </h5>
                                        <div id="collapseFive" class="accordion-collapse collapse"
                                            data-bs-parent="#accordionExample">
                                            <div class="accordion-body p-0 tw-mt-605 max-w-620-px">
                                                <p class="text-neutral-500">
                                                    GoDaddy offers more than just a platform to build
                                                    your website, we offer everything you need to create
                                                    an effective, memorable online presence. Already
                                                    have a site? We offer hosting plans that will keep
                                                    it fast, secure and online. Our professional
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item tw-py-8 tw-px-40-px tw-rounded-xl bg-transparent border-0 mb-0"
                                        data-aos="fade-up" data-aos-anchor-placement="top-bottom"
                                        data-aos-duration="800">
                                        <h5
                                            class="accordion-header d-flex align-items-center justify-content-between tw-gap-3">
                                            <button
                                                class="accordion-button shadow-none p-0 line-clamp-3 bg-transparent h5 collapsed"
                                                type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix"
                                                aria-expanded="false" aria-controls="collapseSix">
                                                Why should I transfer my domain, website or web
                                                hosting to GoDaddy?
                                            </button>
                                        </h5>
                                        <div id="collapseSix" class="accordion-collapse collapse"
                                            data-bs-parent="#accordionExample">
                                            <div class="accordion-body p-0 tw-mt-605 max-w-620-px">
                                                <p class="text-neutral-500">
                                                    GoDaddy offers more than just a platform to build
                                                    your website, we offer everything you need to create
                                                    an effective, memorable online presence. Already
                                                    have a site? We offer hosting plans that will keep
                                                    it fast, secure and online. Our professional
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Faq Two Section End -->

            <!-- footer area -->
                @include('frontend.includes.footers.footerOne')
            <!-- footer area end -->

        </div>
    </div>



@endsection
