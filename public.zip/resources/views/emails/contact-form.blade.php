<h2>You have a new contact form submission</h2>

<p><strong>Name:</strong> {{ $data['name'] }}</p>
<p><strong>Email:</strong> {{ $data['email'] }}</p>
<p><strong>Phone:</strong> {{ $data['phone'] }}</p>

<p><strong>Message:</strong></p>
<p>{{ $data['message'] }}</p>
